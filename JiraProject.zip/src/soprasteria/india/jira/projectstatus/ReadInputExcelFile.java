package soprasteria.india.jira.projectstatus;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadInputExcelFile {

	/**
	 * ! Constant declaration for logWriter
	 */
	private static CreateJS ganttChartWriter;

	private static CreateJS taskPerResourceChartWriter;

	public static void main(String[] args) throws IOException {

		String excelColumns = ToolConfigurationProperties.excelColumns;

		String requiredColumns = ToolConfigurationProperties.requiredColumns;

		String excelColumnFromFile = null;
		FileInputStream inputStream = new FileInputStream(new File(ToolConfigurationProperties.inputExcelFilePath));

		boolean isCriticalityRequired = ToolConfigurationProperties.isCriticalityRequired;

		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

		XSSFSheet firstSheet = workbook.getSheetAt(0);

		Iterator<Row> iterator = firstSheet.iterator();

		HashMap<String, Integer> columnOrderMap = ToolHelper.getColumnOrder(excelColumns);

		boolean requiredColumnsPresent = ToolHelper.checkRequiredColumns(columnOrderMap, requiredColumns);

		if (requiredColumnsPresent) {

			boolean excelHeader = true;

			l1: while (iterator.hasNext()) {

				if (excelHeader) {
					Row nextRow = iterator.next();
					Iterator<Cell> cellIterator = nextRow.cellIterator();
					excelColumnFromFile = ToolHelper.readExcelColumsFromFile(cellIterator);
					excelHeader = false;
					if (!excelColumnFromFile.equals(excelColumns)) {
						System.out.println("Columns in Excel sheet and property file are not same.!");
						break l1;
					}
				} else {
					mapColumnValues(iterator, excelColumns, isCriticalityRequired, columnOrderMap);
				}

				System.out.println();
			}

		} else {
			System.out.println("required Columns are not Present in the Excel Header.");
		}

		workbook.close();
		inputStream.close();

		File file = new File("D:\\Project Status via JIRA\\Project Tracking via Jira - Version 1.html");
		try {
			Desktop desktop = Desktop.getDesktop();
			desktop.browse(file.toURI());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void mapColumnValues(Iterator<Row> iterator, String excelColumns, boolean isCriticalityRequired,
			HashMap<String, Integer> columnOrderMap) throws IOException {

		ganttChartWriter = new CreateJS("D:\\Project Status via JIRA\\js\\amChartGanttChart.js");

		ganttChartWriter.write(
				"function amGanttChart(themeType){var chart = AmCharts.makeChart( \"chartdiv\", {  \"type\": \"gantt\",  \"theme\": themeType,  \"marginRight\": 70,  \"period\": \"DD\",  \"dataDateFormat\": \"YYYY-MM-DD\",  \"columnWidth\": 0.5,  \"valueAxis\": {    \"type\": \"date\"  },  \"brightnessStep\": 7,  \"graph\": {    \"fillAlphas\": 1,    \"lineAlpha\": 1,    \"lineColor\": \"#fff\",    \"fillAlphas\": 0.85,    \"balloonText\": \"<b>[[task]]</b>:<br />[[open]] -- [[value]]\"},  \"rotate\": true,  \"categoryField\": \"category\",  \"segmentsField\": \"segments\",  \"colorField\": \"color\",  \"startDateField\": \"start\",  \"endDateField\": \"end\",  \"dataProvider\": [   ");

		String workLogColor = ToolConfigurationProperties.defaultWorkLogColor;

		Map<String, String> criticalityRatingColorMap = new HashMap<String, String>();

		Map<String, Integer> taskPerresource = new HashMap<String, Integer>();

		if (isCriticalityRequired) {
			criticalityRatingColorMap = ToolHelper.mapCritingRatingAndColor(
					ToolConfigurationProperties.criticalityRating, ToolConfigurationProperties.criticalityColour);
		}
		// add dataprovider

		int i = 1;
		ArrayList<String> taskNamesinExcel = new ArrayList<String>();
		boolean firstCategory = true;

		l1: while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();

			String taskName = null;

			Date logStartDate;

			Date logEndDate = null;

			String loggedStartDate = null;

			String loggedEndDate = null;

			String resource;

			boolean sameTask = false;

			while (cellIterator.hasNext()) {

				Cell cell = cellIterator.next();
				String cellValue = null;

				if (columnOrderMap.get("Key") == i) {
					taskName = cell.getStringCellValue();
					if ("" == taskName) {
						ganttChartWriter.write("]}");
						break l1;
					}
					if (taskNamesinExcel.contains(cell.getStringCellValue())) {
						sameTask = true;
					}
					System.out.print("taskName::" + taskName);
				}

				if (columnOrderMap.get("Date") == i) {
					logStartDate = cell.getDateCellValue();
					logEndDate = new Date(logStartDate.getTime() + TimeUnit.DAYS.toMillis(1));
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					loggedStartDate = formatter.format(logStartDate);
					loggedEndDate = formatter.format(logEndDate);
					System.out.print("loggedDate::" + loggedStartDate);
				}

				if (columnOrderMap.get("Username") == i) {
					boolean existingResource = false;
					resource = cell.getStringCellValue();
					if (taskPerresource.isEmpty()) {
						taskPerresource.put(resource, 1);
					} else {
						for (Map.Entry<String, Integer> entry : taskPerresource.entrySet()) {
							String mapResource = entry.getKey();
							if (mapResource.equals(resource)) {
								existingResource = true;
								int totalTask = entry.getValue() + 1;
								taskPerresource.put(resource, totalTask);
							}
						}
						if (!existingResource) {
							taskPerresource.put(resource, 1);
						}
					}

					System.out.print("resource::" + resource);
				}

				if (isCriticalityRequired && 10 == i) {
					workLogColor = criticalityRatingColorMap.get(String.valueOf(cell.getNumericCellValue()));
				}

				i++;

			}

			if (!sameTask && !firstCategory) {
				ganttChartWriter.write("]},");
			}

			if (!sameTask) {
				ganttChartWriter.write("{\"category\": \"" + taskName + "\",    \"segments\": [ ");
			}

			if (sameTask) {
				ganttChartWriter.write(",");
			}

			ganttChartWriter.write("{      \"start\": \"" + loggedStartDate + "\",      \"end\": \"" + loggedEndDate
					+ "\",	  \"color\": \"" + workLogColor + "\",      \"task\": \"Logged Days Good\"    }");

			taskNamesinExcel.add(taskName);
			firstCategory = false;

			i = 1;

		}

		ganttChartWriter.write(
				" ],  \"valueScrollbar\": {    \"autoGridCount\": true  },  \"chartCursor\": {    \"cursorColor\": \"#55bb76\",    \"valueBalloonsEnabled\": false,    \"cursorAlpha\": 0,    \"valueLineAlpha\": 0.5,    \"valueLineBalloonEnabled\": true,    \"valueLineEnabled\": true,    \"zoomable\": false,    \"valueZoomable\": true  },  \"export\": {    \"enabled\": true  }} );}");

		try {
			if (!taskPerresource.isEmpty()) {
				ToolHelper.writeTaskPerResourceGraph(taskPerResourceChartWriter, taskPerresource);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

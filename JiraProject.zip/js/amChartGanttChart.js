
function amGanttChart(themeType){var chart = AmCharts.makeChart( "chartdiv", {  "type": "gantt",  "theme": themeType,  "marginRight": 70,  "period": "DD",  "dataDateFormat": "YYYY-MM-DD",  "columnWidth": 0.5,  "valueAxis": {    "type": "date"  },  "brightnessStep": 7,  "graph": {    "fillAlphas": 1,    "lineAlpha": 1,    "lineColor": "#fff",    "fillAlphas": 0.85,    "balloonText": "<b>[[task]]</b>:<br />[[open]] -- [[value]]"},  "rotate": true,  "categoryField": "category",  "segmentsField": "segments",  "colorField": "color",  "startDateField": "start",  "endDateField": "end",  "dataProvider": [   
{"category": "RATPMIG-217",    "segments": [ 
{      "start": "2017-07-04",      "end": "2017-07-05",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-310",    "segments": [ 
{      "start": "2017-07-06",      "end": "2017-07-07",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-359",    "segments": [ 
{      "start": "2017-09-11",      "end": "2017-09-12",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-376",    "segments": [ 
{      "start": "2017-07-03",      "end": "2017-07-04",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-387",    "segments": [ 
{      "start": "2017-07-31",      "end": "2017-08-01",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-391",    "segments": [ 
{      "start": "2017-07-03",      "end": "2017-07-04",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-394",    "segments": [ 
{      "start": "2017-07-04",      "end": "2017-07-05",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-395",    "segments": [ 
{      "start": "2017-09-13",      "end": "2017-09-14",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-399",    "segments": [ 
{      "start": "2017-07-13",      "end": "2017-07-14",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-400",    "segments": [ 
{      "start": "2017-07-05",      "end": "2017-07-06",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-401",    "segments": [ 
{      "start": "2017-07-05",      "end": "2017-07-06",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-403",    "segments": [ 
{      "start": "2017-07-04",      "end": "2017-07-05",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-404",    "segments": [ 
{      "start": "2017-07-04",      "end": "2017-07-05",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-410",    "segments": [ 
{      "start": "2017-07-04",      "end": "2017-07-05",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]},
{"category": "RATPMIG-414",    "segments": [ 
{      "start": "2017-07-03",      "end": "2017-07-04",	  "color": "#00ff00",      "task": "Logged Days Good"    }
]}
 ],  "valueScrollbar": {    "autoGridCount": true  },  "chartCursor": {    "cursorColor": "#55bb76",    "valueBalloonsEnabled": false,    "cursorAlpha": 0,    "valueLineAlpha": 0.5,    "valueLineBalloonEnabled": true,    "valueLineEnabled": true,    "zoomable": false,    "valueZoomable": true  },  "export": {    "enabled": true  }} );}